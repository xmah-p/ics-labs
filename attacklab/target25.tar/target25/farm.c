/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_353(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_426()
{
    return 3281031288U;
}

unsigned addval_373(unsigned x)
{
    return x + 3284633920U;
}

unsigned getval_332()
{
    return 3347662857U;
}

unsigned addval_188(unsigned x)
{
    return x + 3284633932U;
}

unsigned addval_484(unsigned x)
{
    return x + 3281017008U;
}

unsigned getval_316()
{
    return 3281025129U;
}

void setval_299(unsigned *p)
{
    *p = 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_409(unsigned x)
{
    return x + 3767224381U;
}

unsigned addval_344(unsigned x)
{
    return x + 2429651271U;
}

void setval_273(unsigned *p)
{
    *p = 3229142665U;
}

unsigned getval_247()
{
    return 3677930120U;
}

void setval_464(unsigned *p)
{
    *p = 2430634056U;
}

unsigned getval_496()
{
    return 3286276424U;
}

void setval_388(unsigned *p)
{
    *p = 3286272344U;
}

unsigned addval_424(unsigned x)
{
    return x + 3534016137U;
}

unsigned getval_488()
{
    return 3230974601U;
}

unsigned getval_265()
{
    return 2429618481U;
}

void setval_365(unsigned *p)
{
    *p = 3375944089U;
}

unsigned getval_320()
{
    return 2462222796U;
}

unsigned getval_355()
{
    return 2464188744U;
}

void setval_380(unsigned *p)
{
    *p = 3465389644U;
}

unsigned getval_118()
{
    return 3687108233U;
}

unsigned getval_351()
{
    return 3223372425U;
}

unsigned getval_106()
{
    return 3348152969U;
}

unsigned getval_412()
{
    return 3385118345U;
}

unsigned addval_473(unsigned x)
{
    return x + 3372798337U;
}

void setval_217(unsigned *p)
{
    *p = 3229929097U;
}

void setval_437(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_137(unsigned x)
{
    return x + 3676360329U;
}

unsigned getval_446()
{
    return 3284307408U;
}

unsigned addval_211(unsigned x)
{
    return x + 3224424841U;
}

void setval_311(unsigned *p)
{
    *p = 3767093322U;
}

void setval_124(unsigned *p)
{
    *p = 3676361097U;
}

void setval_396(unsigned *p)
{
    *p = 3281047944U;
}

unsigned getval_139()
{
    return 3676885385U;
}

unsigned getval_110()
{
    return 3372794377U;
}

unsigned addval_476(unsigned x)
{
    return x + 3525889673U;
}

unsigned addval_444(unsigned x)
{
    return x + 3677930121U;
}

unsigned getval_160()
{
    return 3286272072U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
